// Copyright 2026, Nick Kennedy
// SPDX-License-Identifier: BSL-1.0
// Test harness embeds the approved Monado policy helper.
#include <mach/mach.h>
#include <mach/mach_time.h>
#include <mach/thread_policy.h>
#include <mach/thread_info.h>
#include <pthread.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#define U_LOG_W(...) fprintf(stderr, __VA_ARGS__)
#define U_LOG_I(...) ((void)0)
static bool debug_get_bool_option_macos_compositor_time_constraint(void) { return true; }
static int debug_get_num_option_macos_compositor_computation_pct(void) { return 35; }
static int debug_get_num_option_macos_compositor_constraint_pct(void) { return 70; }
static uint32_t macos_compositor_ns_to_mach_ticks(uint64_t ns, mach_timebase_info_data_t *tb) { return (uint32_t)(ns * tb->denom / tb->numer); }
static _Thread_local int64_t g_macos_compositor_time_constraint_period_ns = 0;
static unsigned applications;
static kern_return_t record_policy_set(thread_t thread, thread_policy_flavor_t flavor, thread_policy_t policy, mach_msg_type_number_t count) {
 applications++;
 return thread_policy_set(thread, flavor, policy, count);
}
#define thread_policy_set record_policy_set
static inline void
macos_compositor_update_time_constraint(int64_t period_ns)
{
	if (!debug_get_bool_option_macos_compositor_time_constraint() || period_ns <= 0) {
		return;
	}

	if (g_macos_compositor_time_constraint_period_ns == period_ns) {
		return;
	}

	int computation_pct = debug_get_num_option_macos_compositor_computation_pct();
	int constraint_pct = debug_get_num_option_macos_compositor_constraint_pct();
	if (computation_pct <= 0 || constraint_pct <= 0 || computation_pct > constraint_pct || constraint_pct > 100) {
		U_LOG_W(
		    "macOS diagnostic: invalid compositor time constraint percentages: computation_pct=%d "
		    "constraint_pct=%d",
		    computation_pct, constraint_pct);
		g_macos_compositor_time_constraint_period_ns = period_ns;
		return;
	}

	uint64_t computation_ns = ((uint64_t)period_ns * (uint64_t)computation_pct) / 100u;
	uint64_t constraint_ns = ((uint64_t)period_ns * (uint64_t)constraint_pct) / 100u;

	mach_timebase_info_data_t timebase = {0};
	kern_return_t kr = mach_timebase_info(&timebase);
	if (kr != KERN_SUCCESS || timebase.numer == 0 || timebase.denom == 0) {
		U_LOG_W("macOS diagnostic: mach_timebase_info failed for compositor time constraint: %d", kr);
		g_macos_compositor_time_constraint_period_ns = period_ns;
		return;
	}

	thread_time_constraint_policy_data_t policy = {
	    .period = macos_compositor_ns_to_mach_ticks((uint64_t)period_ns, &timebase),
	    .computation = macos_compositor_ns_to_mach_ticks(computation_ns, &timebase),
	    .constraint = macos_compositor_ns_to_mach_ticks(constraint_ns, &timebase),
	    .preemptible = TRUE,
	};

	thread_t thread = mach_thread_self();
	kr = thread_policy_set(thread, THREAD_TIME_CONSTRAINT_POLICY, (thread_policy_t)&policy,
	                       THREAD_TIME_CONSTRAINT_POLICY_COUNT);
	mach_port_deallocate(mach_task_self(), thread);
	g_macos_compositor_time_constraint_period_ns = period_ns;

	double refresh_hz = 1000000000.0 / (double)period_ns;
	if (kr == KERN_SUCCESS) {
		U_LOG_I(
		    "macOS diagnostic: Multi Client Module time constraint updated: refresh_hz=%.3f "
		    "period_ns=%lld computation_ns=%llu constraint_ns=%llu computation_pct=%d constraint_pct=%d",
		    refresh_hz, (long long)period_ns, (unsigned long long)computation_ns,
		    (unsigned long long)constraint_ns, computation_pct, constraint_pct);
	} else {
		U_LOG_W(
		    "macOS diagnostic: failed to set Multi Client Module THREAD_TIME_CONSTRAINT_POLICY: kr=%d "
		    "refresh_hz=%.3f period_ns=%lld computation_ns=%llu constraint_ns=%llu",
		    kr, refresh_hz, (long long)period_ns, (unsigned long long)computation_ns,
		    (unsigned long long)constraint_ns);
	}
}


static void *worker(void *arg) {
 macos_compositor_update_time_constraint(8341708);
 macos_compositor_update_time_constraint(8341708);
 thread_time_constraint_policy_data_t policy = {0};
 mach_msg_type_number_t count = THREAD_TIME_CONSTRAINT_POLICY_COUNT;
 boolean_t is_default = FALSE;
 thread_t thread = mach_thread_self();
 kern_return_t kr=thread_policy_get(thread, THREAD_TIME_CONSTRAINT_POLICY, (thread_policy_t)&policy, &count, &is_default);
 mach_port_deallocate(mach_task_self(), thread);
 printf("replacement=%ld kr=%d default=%d period=%u applications=%u\n",(long)arg,kr,is_default,policy.period,applications);
 return (void *)(uintptr_t)(kr != KERN_SUCCESS || is_default || policy.period == 0);
}
int main(void) {
 for (long n=0;n<3;n++) {
  pthread_t t; void *result;
  if (pthread_create(&t,NULL,worker,(void*)n) || pthread_join(t,&result) || result) return 1;
 }
 if(applications != 3) return 2;
 puts("PASS: three replacement threads apply policy once each at the same refresh period");
 return 0;
}
